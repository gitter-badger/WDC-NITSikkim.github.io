
<?php include 'includes/header.php'; ?>

 

        <div id="annon_head" style="padding-left:32px;">
          <h2><b>Student Portal</b></h2>
          <hr>
        </div>
		
		
	<!---------------------------------------------------------------------php to get data-------------------------------------->

<?php
if($_POST){
	
	
	
	echo '<div class="row" style="padding-left:15%;padding-right:15%;">
				
				<div class="col-md-12" >
					<div class="panel panel-default" style="border-radius: 1.5em;border-color:#3C7570; background-color:#e5e0e0;border-width: thick">
						
						<div class="panel-body">';
	
	
	
	
	
	
	$con =  mysqli_connect('localhost','root','','registration');
	
	
	
	
	
	
	
	$u=mysqli_real_escape_string($con,$_POST['username']);

$p=md5($_POST['password']);

$sql="SELECT `Name`,`Password`,`Email id` FROM `new registration` WHERE `Roll`= '$u'";
	$passw=mysqli_query($con,$sql) or die("error ..no such user registered".mysqli_error($con));
           
			$pas=mysqli_fetch_array($passw);
			$pass=$pas['Password'];
			$user=$pas['Name'];
			$email=$pas['Email id'];
			
if(($p==$pass))
{
	
	session_start();
	$_SESSION['username']=$u;
	$_SESSION['name']=$user;
	$_SESSION['email']=$email;
	echo "<script> location.href='user.php'; </script>";
        exit;
}
else
{
	
	
	echo '<span style="color:red;text-align:center;padding-left:30%;"><b><h3>&#10008;&nbsp&nbspInvalid username or password!!! Please try again. </h3></b></span>';
}



echo '</div>
</div>
</div>
</div>';
}

?>

<!-------------------------------------------------------------------------------------------------------------------------->
	
	
	
	
	
	
  <div class="row">
  
    
	         
			 <!----<div class="col-md-4" >
						
						<ul style="background-color:#e5e0e0;list-style:none;">
						
						
							<li><img src="images/log.png"/ style="height:450px; float:left;"></li>
							
						</ul>
				
				</div>---------->
	<div class="col-md-12">
					
							

		<div class="container" >
			
			<div class="row" >
				<div class="col-md-12">
					<div class="panel panel-default"style="border-color:#e5e0e0; background-color:#e5e0e0;">
						
						<div class="panel-body">
							
							
<!---------------------------------------------------------------------------------------------------------------------------->
                              


		 
<!-----------------------------------------------------student login----------------------------------------------------------------------->							 
							 
							 
		


  
  <!-- Trigger the modal with a button -->
  <!--button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Open Modal</button-->

  <!-- Modal -->
  
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header" style="background-color:teal;border-radius:5px 5px 0px 0px;">

          <h2 style="text-align:center;">Login to Your Account</h2>
        </div>
        <div class="modal-body">
          <form action="" method="post" class="form-horizontal">
  <div class="form-group">
    <label class="control-label col-sm-3" for="email">Username:</label>
    <div class="col-sm-9">
      <input  name="username" class="form-control" id="email" placeholder="Enter username">
    </div>
  </div>
  <div class="form-group">
    <label class="control-label col-sm-3" for="pwd">Password:</label>
    <div class="col-sm-9"> 
      <input type="password" name="password" class="form-control" id="pwd" placeholder="Enter password">
    </div>
  </div>
  <div class="form-group"> 
    <div class="col-sm-offset-2 col-sm-10">
      
    </div>
  </div>
  <div class="form-group"> 
    <div class="col-sm-offset-2 col-sm-10" style="padding-left:11%;">
      <button type="submit" class="btn btn-primary">Login</button>
    </div>
  </div>
</form>
        </div>
        <div class="modal-footer">
          <a href="#"><button type="button" class="btn btn-danger" data-dismiss="modal">Forgot password?</button></a>
		  <a href="registration_form.php"><button type="button" class="btn btn-success" data-dismiss="modal">New user? register!!!</button></a>
        </div>
      </div>
      
    </div>
  
  



					 
							 
<!----------------------------------------------------------------------------------------------------------------------------------->							 
							
							
							
							
						</div>
					</div>
				</div>
				
				
			</div>
		</div>
    </div>				
							
							
							
							
							
				
				
				
												
					
				
				
					
			
				
  
  
</div>





<?php include 'footer.php'; ?>
