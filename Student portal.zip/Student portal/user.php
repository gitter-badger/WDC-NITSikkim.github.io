<?php 
session_start();
if (!isset($_SESSION['username']))
	header('location: registration.php');
?>
<?php include 'includes/header.php'; ?>

 <form action="" method="post">
    <div class="form-inline ">
          
          <h4><b>User:<span style="color:green;"><i>
		  <?php
		  
		 $user=$_SESSION['username'];
		  echo $user;
		  
		  ?>
		  
		  
		  
		  </i></span></b></h4>
		  
      <button type="submit" name="logout"class="btn btn-danger">Logout</button>
    
          <hr>
        
        
	</div>	
  </form>
 
	
	
	
	
	
<?php
if(isset($_POST['logout'])){

{
	session_destroy();
	echo "<script> location.href='registration.php'; </script>";
        exit;
}

}
?>
	
	
	
	
	
	
  <div class="row">
  
    
	         
			 <!----<div class="col-md-4" >
						
						<ul style="background-color:#e5e0e0;list-style:none;">
						
						
							<li><img src="images/log.png"/ style="height:450px; float:left;"></li>
							
						</ul>
				
				</div>---------->
	<div class="col-md-12">
					
							

		<div class="container" >
			
			<div class="row" >
				<div class="col-md-3">
					<div class="panel panel-default"style="border-radius: 1.5em;border-color:#3C7570; background-color:#e5e0e0;border-width: thick;">
						<div class="panel-heading"style="background-color:#e5e0e0;border-radius: 1.5em 1.5em 0em 0em;"id="annon_head">
							<div   style="text-align:center;height:20px;color:#9E9EA7;padding-top:5px;"><h2><b>Activities</b></h2><hr></div>
						</div>
						<div class="panel-body">
													<p> 
							 <a href="change.php">
							 <button type="button" class="btn  btn-info btn-lg" style="color:black;width:90%;margin-left:5%;">
                             <!--<span class="glyphicon glyphicon-search"></span---->Change password
                             </button></a>
							</p>
						<p> <a href="ruser_list.php">
							 <button type="button" class="btn  btn-info btn-lg" style="color:black;width:90%;margin-left:5%;">
                             <!--<span class="glyphicon glyphicon-search"></span------>Registration
                             </button></a>	
							
<!---------------------------------------------------------------------------------------------------------------------------->
                              


<!-----------------------------------------------------student login----------------------------------------------------------------------->							 
							 
							 
		


 



					 
							 
<!----------------------------------------------------------------------------------------------------------------------------------->							 
							</p>
							<p> 
							 <a href="view.php">
							 <button type="button" class="btn btn-info btn-lg" style="color:black;width:90%;margin-left:5%;">
                             <!--<span class="glyphicon glyphicon-search"></span--->Edit/Print form
                             </button></a>
							</p>
							<p> 
							 <a href="querry.php">
							 <button type="button" class="btn  btn-info btn-lg" style="color:black;width:90%;margin-left:5%;">
                             <!--<span class="glyphicon glyphicon-print"></span>-->File querry
                             </button></a>
							</p>
							<p> 
							 <a href="#">
							 <button type="button" class="btn  btn-info btn-lg" style="color:black;width:90%;margin-left:5%;">
                             <!--<span class="glyphicon glyphicon-print"></span>-->Result
                             </button></a>
							</p>
							
							
						</div>
					</div>
				</div>
<!--------------------------------------------------------content start--------------------------------------------------------------------------------->
			
  
    
	         
			
	<div class="col-md-9">	       





					   <div id="annon_head" style="padding-left:32px;">
          <h2><b>WELCOME</b></h2>
          <hr>
        </div>
		
	
			
			<div class="row" >
				
				<div class="col-md-12" >
					<div class="panel panel-default"style="border-radius: 1.5em;border-color:#3C7570; background-color:#e5e0e0;border-width: thick;">
						<!---<div class="panel-heading"style="background-color:#e5e0e0;border-radius: 1.5em 1.5em 0em 0em;"id="annon_head">
							<div   style="text-align:center;height:20px;color:#9E9EA7;padding-top:5px;"><h2>Administration</h2><hr></div>
						</div>-->
						<div class="panel-body">	
	
	<span style="color:green;text-align:center;padding-left:30%;"><i><b><h2>WELCOME : <?php
		  
		 $use=$_SESSION['name'];
		  echo $use;
		  
		  ?></h2></b></i> </span>
	
	<span style="color:teal;text-align:center;padding-left:30%;"><h2><img src="images/arrow.png" ></span><span><b>&nbsp&nbsp&nbsp&nbsp&nbspChoose what to do from activities.</h2></b> </span>
	
	
	
	
  </div>
  </div>
  </div>
  </div>
  
					
							

		
			
			
		
    </div>				
							
							
							
							
							
				
				
				
												
					
				
				
					
			
				
  
  





	<!---------------------------------------------------------end------------------------------------------------------------------------>			
			</div>
		</div>
    </div>				
							
							
							
							
							
				
				
				
												
					
				
				
					
			
				
  
  
</div>
<br><br><br>


<!---------------------------------------------------------------------php to get data-------------------------------------->



<!-------------------------------------------------------------------------------------------------------------------------->

<?php include 'footer.php'; ?>
