<?php 
session_start();
if (!isset($_SESSION['username']))
	header('location: registration.php');
?>
<div style="min-width:850px;background-color:#e5e0e0;" >

<?php include 'includes/header.php'; ?>

 <form action="" method="post">
    <!--------------------------------------------------------------------------------------------------------------------->
	<head>
	<style>
  
  .affix {
      top: 0; left :0;
      width: 100%;
      z-index: 9999 !important;
	  background-color:#009688;
	  
  }

  .affix + .container-fluid{
      padding-top: 70px;
	  background-color:#009688;
	  
  }
  </style>
	</head>
	
	<div>
	<nav class="navbar navbar-default "  data-spy="affix" data-offset-top="197">
				<div class="container-fluid">
					<div class="navbar-header">
					  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>                        
					  </button>
					  <h4><b>User:<span style="color:green;"><i>
		  <?php
		 $user=$_SESSION['username'];
		  echo $user;
		  
		  ?>
		  
		  
		  
		  </i></span></b></h4>
		  <button type="submit" name="logout"class="btn btn-danger">Logout</button>
					</div>
					<div class="collapse navbar-collapse" id="myNavbar">
						<ul class="nav navbar-nav navbar-right">
						    <li><a href="change.php">
							 <button type="button" class="btn btn-info btn-lg" style="color:black;">
                             <!--<span class="glyphicon glyphicon-search"></span--->Change password
                             </button></a> </li>
							
							<li><a href="ruser_list.php">
							 <button type="button" class="btn  btn-info btn-lg" style="color:black;overflow:hidden;">
                             <!--<span class="glyphicon glyphicon-search"></span------>Registration
                             </button></a></li>
							<li><a href=""><button type="button" class="btn btn-default btn-lg disabled" style="color:red;">
                             <!--<span class="glyphicon glyphicon-search"></span----><b>Edit/Print form</b>
                             </button></a></li>
							<li><a href="querry.php">
							 <button type="button" class="btn  btn-info btn-lg" style="color:black;">
                             <!--<span class="glyphicon glyphicon-print"></span>-->File querry
                             </button></a> </li>
							<li>
							 <a href="#">
							 <button type="button" class="btn  btn-info btn-lg" style="color:black;">
                             <!--<span class="glyphicon glyphicon-print"></span>-->Result
                             </button></a>
							 </li>
						</ul>
					</div>
				</div>
			</nav>
	
	
	
	<!--------------------------------------------------------------------------------------------------------------------->
    
          <hr>
        
        
	</div>	
  </form>
 
	
	
	
	
	
<?php
if(isset($_POST['logout'])){

{
	session_destroy();
	echo "<script> location.href='registration.php'; </script>";
        exit;
}

}
?>
	
	
	
	
	
	
  <div class="row">
  
    
	         
			 <!----<div class="col-md-4" >
						
						<ul style="background-color:#e5e0e0;list-style:none;">
						
						
							<li><img src="images/log.png"/ style="height:450px; float:left;"></li>
							
						</ul>
				
				</div>---------->
	<div class="col-md-12">
					
							

		<div class="container" >
			
			<div class="row" >
				
<!--------------------------------------------------------content start--------------------------------------------------------------------------------->
			
  
    
	         
			
	<div class="col-md-12" >	       





					   <div id="annon_head" style="padding-left:32px;">
          <h2><b>View/Edit Form</b></h2>
          <hr>
        </div>
		
		
	
	
	
	
	
	
	
  
					
							

		
			
			<div class="row" style="padding-left:10%;padding-right:10%;" >
				
				<div class="col-md-12" >
					<div class="panel panel-default"style="border-radius: 1.5em;border-color:#3C7570; background-color:#e5e0e0;border-width: thick;">
						<!---<div class="panel-heading"style="background-color:#e5e0e0;border-radius: 1.5em 1.5em 0em 0em;"id="annon_head">
							<div   style="text-align:center;height:20px;color:#9E9EA7;padding-top:5px;"><h2>Administration</h2><hr></div>
						</div>-->
						<div class="panel-body">
						
						
						
						
						<!--------------------form header-------------------------------------------------------->
							
							
  
  <form action="" method="post" class="form-horizontal">
  
  <div class="form-group">
    <label class="control-label col-sm-3" for="pwd">Roll No.:</label>
    <div class="col-sm-9"> 
      <input type="text" class="form-control" name="username" id="pwd" placeholder="<?php
		 $user=$_SESSION['username'];
		  echo $user;
		  
		  ?>" value="<?php
		 $user=$_SESSION['username'];
		  echo $user;
		  
		  ?>" readonly>
    </div>
  </div>
  <!---div class="form-group">
    <label class="control-label col-sm-3" for="pwd">New Password:</label>
    <div class="col-sm-9"> 
      <input type="password" class="form-control" name="new" id="pwd" placeholder="Enter password">
    </div>
  </div>
  <div class="form-group">
    <label class="control-label col-sm-3" for="pwd">Confirm Password:</label>
    <div class="col-sm-9"> 
      <input type="password" class="form-control" name="confirm" id="pwd" placeholder="Enter password">
    </div>
  </div-->
 
 
 <?php
if($_POST){


$u=$_SESSION['username'];

$con= mysqli_connect('localhost','root','','registration');
$sql="SELECT * FROM  `registration` WHERE `Roll`= '$u'";
$result=mysqli_query($con,$sql) or die("error ..semister registerion not done!! ".mysqli_error($con));
           
			$row=mysqli_fetch_array($result);
			echo '<hr  style="border-width: medium;border-color:#3C7570;">';		
echo ('<table  style="border-radius: 1.5em;border-color:#3C7570; background-color:#e5e0e0;border-width: medium;" class="table table-striped table-responsive"  >');

if($row)	
{
	
	$dcount=0;
	$columns=count($row);
	while ($fieldinfo=mysqli_fetch_field($result))
	{
	for($c=0;$c<$columns;$c++)
	{ if(isset($row[$c]))
		{
		if($dcount==2)
		{echo '</tr><tr>';
	     $dcount=0;
		}
		if(($fieldinfo->name)=="Subject(s) opted {semister}")
			{
			echo ('<tr></tr><tr><td style="padding:0px;"><span style="color:black;"><h4><b>'.$fieldinfo->name." : ".'</h4> </b></span></td><td style="padding:0px;"><span style="color:teal;"><h4><b>'.$row[$c].' </h4></b></span></td></tr>');
		    $dcount++;	$dcount++;
			}
			else
			{
	    echo ('<td style="padding:0px;width:50%;"><span style="color:black;"><b><h4>'.$fieldinfo->name." : ".' </b></span><span style="color:teal;"><b>'.$row[$c].' </h4></b></span></td>');
		$dcount++;
			}
		}
		
	   $fieldinfo=mysqli_fetch_field($result);
	}
	$row=mysqli_fetch_array($result);
	
	}
	
	
	
	echo "</table>";

   echo ('<div class=" col-sm-5" style="padding-left:20%;">
      <a href="edit_form.php"><button type="button" class="btn btn-danger btn-lg">&#10001;&nbspEdit your form</button></a>
    </div>');
	 echo ('<div class=" col-sm-5" style="padding-left:20%;">
      <a href="print.php"><button type="button" class="btn btn-success btn-lg">&#128439&nbspGo To Printable page</button></a>
    </div>');
}
else
{
	echo '<span style="color:red;text-align:center;"><b><h4>REGISTRATION NOT DONE!!!!!! </b></h4></span>';
	echo '<a href="ruser_list.php"><span style="color:teal;text-align:center;"><b><h4>CLICK HERE TO DO REGISTRATION . </b></h4></span></a>';
}
	








   

echo "<br><br><br>";
}
else 
{
	
	echo (' <div class="form-group"> 
    <div class="col-sm-offset-2 col-sm-10" style="padding-left:25%;">
      <button type="submit" class="btn btn-primary btn-lg">View your semister registration form </button>
    </div>
  </div>');
  
	
	
}
?>
 
 
 
 
 
 
 
 
 
 
</form>
  

							
							
							
							
						<!----------------------------------------------------------------------------------------->	
						</div>
						
						
						
					</div>
				</div>
				
			
		
    			
							
							
							
							
							
				
				
				
												
					
				
				
					
			
				
  
  





</div>

</div>	
	<!---------------------------------------------------------end------------------------------------------------------------------------>			
			</div>
		</div>
    </div>				
							
							
							
							
							
				
				
				
												
					
				
				
					
			
				
  
  
</div>
<br><br><br>


<!---------------------------------------------------------------------php to get data-------------------------------------->



<!-------------------------------------------------------------------------------------------------------------------------->

<?php include 'footer.php'; ?>
</div>